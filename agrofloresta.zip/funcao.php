<?php 
	function menu(){
		?>
			<p class="link">
				<a href="form_localizacao.php"> Cadastrar Localização </a> |
				<a href="form_area.php"> Cadastrar Área </a> |
				<a href="form_cultura.php"> Cadastrar Cultura </a>
			</p>
		<?php
	}
	
	function lista(){
		
		?>
		
			<p class="link">
				<a href="listar_localizacao.php"> Listar Localizações </a> |
				<a href="listar_area.php"> Listar Áreas </a> |
				<a href="listar_cultura.php"> Listar Cultura </a>
			</p>
		
		<?php
		
	}
	
?>